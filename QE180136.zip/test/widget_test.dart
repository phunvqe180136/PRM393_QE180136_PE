import 'package:flutter_test/flutter_test.dart';

void main() {
  test('Smoke test placeholder', () {
    expect(1 + 1, 2);
  });
}
